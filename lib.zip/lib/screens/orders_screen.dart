import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rwnaqk/controllers/orders/orders_controller.dart';
import 'package:rwnaqk/core/constants/app_colors.dart';
import 'package:rwnaqk/core/routes/app_routes.dart';
import 'package:rwnaqk/widgets/orders/order_card.dart';
import 'package:rwnaqk/widgets/orders/orders_filter_tabs.dart';

class OrdersScreen extends GetView<OrdersController> {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsetsDirectional.fromSTEB(8, 6, 8, 0),
          child: Column(
            children: [
              Row(
                children: [
                  Text(
                    'طلباتي'.tr,
                    style: TextStyle(
                      color: context.foreground,
                      fontWeight: FontWeight.w900,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),

              Obx(() {
                return OrdersFilterTabs(
                  value: controller.filter.value,
                  onChanged: controller.setFilter,
                );
              }),
              const SizedBox(height: 12),

              Expanded(
                child: Obx(() {
                  final list = controller.filteredOrders;

                  if (list.isEmpty) {
                    return Center(
                      child: Text(
                        'لا يوجد طلبات حالياً'.tr,
                        style: TextStyle(
                          color: context.muted,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    );
                  }

                  return ListView.separated(
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (_, i) {
                      final o = list[i];
                      return OrderCard(
                        order: o,
                        onTap: () =>
                            Get.toNamed(AppRoutes.orderTracking, arguments: o),
                      );
                    },
                  );
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}